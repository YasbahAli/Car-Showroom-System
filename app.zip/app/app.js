const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

app.use(cors());
app.use(bodyParser.json());

// Oracle connection config
const dbConfig = {
  user: "C##Car_Showroom_System",
  password: "fast",
  connectionString: "localhost:1521/xe"
};

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);

    // Check if user exists with matching password
    const result = await connection.execute(
      `SELECT custid FROM customer WHERE username = :username AND password1 = :password`,
      [username, password]
    );

    if (result.rows.length > 0) {
      res.json({ success: true, message: "Login Successful", custid: result.rows[0].CUSTID });
    } else {
      res.json({ success: false, message: "Invalid Credentials" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server Error" });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection', err);
      }
    }
  }
});

app.post('/admin-login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const connection = await oracledb.getConnection({
        user: "C##Car_Showroom_System",
        password: "fast",
        connectionString: "localhost:1521/xe"
      });
  
      const result = await connection.execute(
        `SELECT username, password1 FROM administrator WHERE username = :username AND password1 = :password`,
        { username, password }
      );
  
      if (result.rows.length > 0) {
        res.json({ success: true, message: 'Admin login successful' });
      } else {
        res.json({ success: false, message: 'Invalid admin credentials' });
      }
  
      await connection.close();
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: 'Database error' });
    }
  });

  app.post('/owner-login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const connection = await oracledb.getConnection({
        user: "C##Car_Showroom_System",
        password: "fast",
        connectionString: "localhost:1521/xe"
      });
  
      const result = await connection.execute(
        `SELECT * FROM owners WHERE username = :username AND password1 = :password`,
        { username, password }
      );
  
      if (result.rows.length > 0) {
        res.json({ success: true, message: 'Owner login successful', ownerid: result.rows[0].OWNERID });
      } else {
        res.json({ success: false, message: 'Invalid owner credentials' });
      }
  
      await connection.close();
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: 'Database error' });
    }
  });

  app.get('/admin-data', async (req, res) => {
    try {
      const connection = await oracledb.getConnection({
        user: "C##Car_Showroom_System",
        password: "fast",
        connectionString: "localhost:1521/xe"
      });
  
      const adminResult = await connection.execute(`SELECT * FROM ADMINISTRATOR`);
      const ownersResult = await connection.execute(`SELECT * FROM OWNERS`);
      const inventoryResult = await connection.execute(`SELECT * FROM INVENTORY`);
      const customersResult = await connection.execute(`SELECT * FROM CUSTOMER`);
      const rentedCarsResult = await connection.execute(`SELECT * FROM RENTED_CARS`);
      const soldCarsResult = await connection.execute(`SELECT * FROM SOLD_CARS`);
  
      res.json({
        administrators: adminResult.rows,
        owners: ownersResult.rows,
        inventory: inventoryResult.rows,
        customers: customersResult.rows,
        rentedCars: rentedCarsResult.rows,
        soldCars: soldCarsResult.rows
      });
  
      await connection.close();
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: 'Database error' });
    }
  });
  

app.get('/admin-data', async (req, res) => {
  let connection;
  try {
      connection = await oracledb.getConnection({
          user: "C##Car_Showroom_System",
          password: "fast",
          connectionString: "localhost:1521/xe"
      });

      const tables = ['ADMINISTRATOR', 'OWNERS', 'INVENTORY', 'CUSTOMER', 'RENTED_CARS', 'SOLD_CARS'];
      const data = {};

      for (const table of tables) {
          const result = await connection.execute(`SELECT * FROM ${table}`);
          data[table.toLowerCase()] = result.rows;
      }

      res.json(data);
  } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error fetching data' });
  } finally {
      if (connection) await connection.close();
  }
});

const primaryKeyMap = {
  ADMINISTRATOR: 'ADMINID',
  OWNERS: 'OWNERID',
  INVENTORY: 'VEHID',
  CUSTOMER: 'CUSTID',
  RENTED_CARS: ['VEHID', 'OWNERID', 'CUSTOMERID'],
  SOLD_CARS: ['VEHID', 'OWNERID', 'CUSTOMERID']
};


// NEW: Modify data (Insert / Update / Delete)
app.post('/modify-data', async (req, res) => {
  const { table, action, data } = req.body;
  let connection;

  try {
      connection = await oracledb.getConnection({
          user: "C##Car_Showroom_System",
          password: "fast",
          connectionString: "localhost:1521/xe"
      });

      const tableName = table.toUpperCase();
      const pk = primaryKeyMap[tableName];

      if (action === 'insert') {
          const columns = Object.keys(data).join(',');
          const values = Object.keys(data).map(k => `:${k}`).join(',');
          const sql = `INSERT INTO ${table} (${columns}) VALUES (${values})`;

          await connection.execute(sql, data, { autoCommit: true });

      } else if (action === 'update') {
          const keys = Object.keys(data).filter(k => !(Array.isArray(pk) ? pk.includes(k) : k === pk));
          const setClause = keys.map(k => `${k} = :${k}`).join(', ');
          const whereClause = Array.isArray(pk)
          ? pk.map(k => `${k} = :${k}`).join(' AND ')
          : `${pk} = :${pk}`;
          const sql = `UPDATE ${tableName} SET ${setClause} WHERE ${whereClause}`;
          await connection.execute(sql, data, { autoCommit: true });

      } else if (action === 'delete') {
          const whereClause = Array.isArray(pk)
          ? pk.map(k => `${k} = :${k}`).join(' AND ')
          : `${pk} = :${pk}`;
          const sql = `DELETE FROM ${tableName} WHERE ${whereClause}`;
          await connection.execute(sql, data, { autoCommit: true });
      }

      res.json({ message: 'Operation successful' });

  } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error modifying data' });
  } finally {
      if (connection) await connection.close();
  }
});

// Fetch inventory for a specific owner
app.get('/owner-inventory/:ownerid', async (req, res) => {
  const { ownerid } = req.params;
  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute(
      `SELECT * FROM INVENTORY WHERE OWNERID = :ownerid`,
      [ownerid]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching inventory' });
  } finally {
    if (connection) await connection.close();
  }
});

// Insert/Update/Delete inventory for a specific owner
// Insert/Update/Delete inventory for a specific owner
app.post('/owner-modify-inventory', async (req, res) => {
  const { action, data } = req.body;

  let connection;
  try {
      connection = await oracledb.getConnection(dbConfig);;

      if (action === 'insert') {
          const result = await connection.execute(
              `INSERT INTO INVENTORY (VEHID, OWNERID, VEHNAME, VEHDESCRIPTION, VEHCOST, VEHTYPE, VEHMODEL)
               VALUES (:vehid, :ownerid, :vehname, :vehdescription, :vehcost, :vehtype, :vehmodel)`,
              [data.vehid, data.ownerid, data.vehname, data.vehdescription, data.vehcost, data.vehtype, data.vehmodel],
              { autoCommit: true }
          );
          res.json({ message: 'Vehicle added successfully!' });
      } 
      else if (action === 'update') {
          const result = await connection.execute(
              `UPDATE INVENTORY SET VEHNAME = :vehname, VEHDESCRIPTION = :vehdescription, 
               VEHCOST = :vehcost, VEHTYPE = :vehtype, VEHMODEL = :vehmodel
               WHERE VEHID = :vehid AND OWNERID = :ownerid`,
              [data.vehname, data.vehdescription, data.vehcost, data.vehtype, data.vehmodel, data.vehid, data.ownerid],
              { autoCommit: true }
          );
          res.json({ message: 'Vehicle updated successfully!' });
      } 
      else if (action === 'delete') {
          const result = await connection.execute(
              `DELETE FROM INVENTORY WHERE VEHID = :vehid AND OWNERID = :ownerid`,
              [data.vehid, data.ownerid],
              { autoCommit: true }
          );
          res.json({ message: 'Vehicle deleted successfully!' });
      } else {
          res.status(400).json({ message: 'Invalid action!' });
      }
  } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Error processing request!' });
  } finally {
      if (connection) {
          try {
              await connection.close();
          } catch (err) {
              console.error(err);
          }
      }
  }
});

// Get filtered inventory
app.get('/inventory', async (req, res) => {
  const { cost, type, model } = req.query;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);

    // Start the base query
    let queryStr = 'SELECT * FROM INVENTORY i WHERE NOT EXISTS (SELECT 1 FROM SOLD_CARS s WHERE s.vehid = i.vehid)';

    const conditions = [];
    const binds = {};

    // Add conditions only if parameters are provided
    if (cost) {
      conditions.push("vehcost <= :cost");
      binds.cost = cost;
    }
    if (type) {
      conditions.push("vehtype = :type");
      binds.type = type;
    }
    if (model) {
      conditions.push("vehmodel = :model");
      binds.model = model;
    }

    // If we have any conditions, append them to the query
    if (conditions.length > 0) {
      queryStr += " AND " + conditions.join(" AND ");
    }

    // Execute the query with the binds
    const result = await connection.execute(queryStr, binds, { outFormat: oracledb.OUT_FORMAT_OBJECT });

    // Send the results as a JSON response
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  } finally {
    if (connection) await connection.close();
  }
});


// Buy a car
app.post('/buy-car', async (req, res) => {
  const { custid, vehid } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);

    // Get car cost & ownerid
    const carResult = await connection.execute(`SELECT vehcost, ownerid FROM INVENTORY WHERE vehid = :vehid`, [vehid]);
    if (carResult.rows.length === 0) return res.json({ success: false, message: 'Car not found' });

    const [vehcost, ownerid] = carResult.rows[0];

    // Check customer balance
    const balanceResult = await connection.execute(`SELECT balance FROM CUSTOMER WHERE custid = :custid`, [custid]);
    const balance = balanceResult.rows[0][0];

    if (balance < vehcost) return res.json({ success: false, message: 'Insufficient balance' });

    // Deduct balance
    await connection.execute(`UPDATE CUSTOMER SET balance = balance - :cost WHERE custid = :custid`, [vehcost, custid]);

    // Insert into SOLD_CARS
    await connection.execute(`
      INSERT INTO SOLD_CARS (vehid, ownerid, customerid) VALUES (:vehid, :ownerid, :custid)
    `, [vehid, ownerid, custid]);

    await connection.commit();

    res.json({ success: true, message: 'Purchase successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Purchase failed' });
  } finally {
    if (connection) await connection.close();
  }
});


app.get('/customer-purchases/:custid', async (req, res) => {
  const custid = req.params.custid;

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);

    const result = await connection.execute(
      `SELECT sc.vehid, i.vehname, i.vehdescription, i.vehcost, i.vehtype, i.vehmodel
       FROM sold_cars sc
       JOIN inventory i ON sc.vehid = i.vehid
       WHERE sc.customerid = :custid`,
      [custid]
    );

    res.json({ success: true, cars: result.rows });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  } finally {
    if (connection) await connection.close();
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});